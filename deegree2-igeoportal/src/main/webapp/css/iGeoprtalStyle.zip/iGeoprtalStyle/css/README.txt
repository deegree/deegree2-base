2010-03-18:

ext-all.css contains all css information (including the default blue theme).
There is no need for you to edit this file, if you like to display other themes.

To display another theme perform the following steps:

1. Place your new css file ("test.css") into the folder: javascript/ext-3.0.0/resources/css/

2. Place your new image folder ("test") into the folder: javascript/ext-3.0.0/resources/images/
   this folder must have the exact same structure as the "default" folder
  
3. Go to WEB-INF/conf/igeoportal/viewcontext_extjs.xsl
   There you find the tag 
   <link rel="stylesheet" type="text/css" href="./javascript/ext-3.0.0/resources/css/ext-all.css" />			
   Copy this tag and replace the "ext-all.css" with the name of your new css file ("test.css").
   Finally there should be two references: "ext-all.css" and "test.css".
   Please do not remove the reference for "ext-all.css" !!!! It is needed for the basic css information.
   
That's it.


   
   